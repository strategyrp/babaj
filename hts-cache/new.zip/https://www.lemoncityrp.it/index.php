<!-- <s?php session_start(); ?> -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>LemonCity | Homepage</title>
	<meta name="description" content="LemonCityRP Server FiveM Italiano">
  <meta content="lemoncity, rp, lemon city, lemon city rp,lemoncityrp" name="description">
  <meta content="lemoncity, lemon city, lemon city rp, rp, lemoncityrp, fivem, italy, fullrp, lemoncityfivem, server fivem, ita" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon-logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Roboto:300,400,500,600,700|Poppins:300,400,500,600,700" rel="stylesheet"> -->
  

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script> -->


  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">


<body>

  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-between">
      <h1 class="logo"><a href="https://lemoncityrp.it/"><strong>LemonCity</strong></a></h1>
      <!-- Disattiva e attiva darkmode -->
      <input type="checkbox" class="toggle--checkbox darkmode" id="toggle">
      <label for="toggle" class="toggle--label"></label>
       
      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto " href="https://lemoncityrp.it">Home</a></li>
          <li><a class="nav-link scrollto" href="https://lemoncityrp.it/staff">Staff</a></li>
          <li><a class="nav-link scrollto" href="https://store.lemoncityrp.it">Store</a></li>
          <li><a class="nav-link scrollto" href="#faq">FAQ</a></li>
			    <li><a class="nav-link scrollto" href="changelog">ChangeLog</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contattaci</a></li>
          <li><a class="getstarted" href="fivem://connect/5.181.31.125:30120">Gioca</a></li>
          
        </ul>
        
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>

    </div>
  </header>

  <section id="hero" class="d-flex align-items-center">
    
    <div class="container" data-aos="fade-up">
      <div class="row justify-content-center">
        <div class="col-xl-5 col-lg-6 pt-3 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
          <h1>LemonCity RP</h1>
          <h2>Vivi un'esperienza unica ed indimenticabile</h2>
          <div><a href="#about" class="btn-get-started scrollto">Inizia</a></div>
        </div>
        <div class="col-xl-4 col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="150">
        <img src="assets/img/hero-img.png" class="img-fluid animated" alt="" width="582px" height="732px"> 
        </div>
      </div>
    </div>

  </section>

  <main id="main">

    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>Informazioni</h2>
          <p><strong>LemonCity</strong> è nato da un gruppo di amici con l’intento di dare una casa a coloro che vogliono svagarsi e dilettarsi nel Gioco Di Ruolo (RolePlay).<br>Lo Staff si impegna costantemente per aiutare la propria utenza, cercando di non far loro mai mancare l’affetto che una famiglia dona a coloro a cui ci tiene.</p>
        </div>
          <div class="content" data-aos="fade-right">
            <a href="#features" class="read-more">Scopri di più<i class="bi bi-long-arrow-right"></i></a>
          </div>

      </div>
    </section>

  <section id="counts" class="counts">
      <div class="container">

        <div class="row counters">

          <div class="col-lg-4 col-6 text-center" data-aos="fade-up">
            <span>300+</span>
            <p>Media Giocatori</p>
          </div> 

          <div class="col-lg-4 col-6 text-center" data-aos="fade-up">
           <span data-purecounter-start="0" data-purecounter-end= 0 data-purecounter-duration="1.5" class="purecounter"></span>
            <p>Giocatori Online</p>
          </div> 

          <div class="col-lg-4 col-6 text-center" data-aos="fade-up">
          <span data-purecounter-start="0" data-purecounter-end= 28499 data-purecounter-duration="1.5" class="purecounter centrastaroba"></span> 
            <p class="centrastaroba">Membri Discord</p>
          </div> 

        </div>

      </div>
    </section>

    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Peculiarità</h2>
          <p>Di seguito vi elenchiamo alcune delle nostre feature che contraddistinguono il nostro server dagli altri:</p>
        </div>

        <div class="row">
          <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column align-items-lg-center">
            <div class="icon-box mt-5 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-badge-check"></i>
              <h4>Staff Attivo 24/7</h4>
              <p>Bisogno di supporto? Per ogni richiesta/problematica il nostro Staff sarà lieto di fornirti la miglior assistenza possibile.</p>
            </div>
            <div class="icon-box mt-5" data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-hdd"></i>
              <h4>Server Ottimizzato</h4>
              <p>La nostra Gamemode è stata realizzata con cura per garantire un'esperienza di gioco unica</p>
            </div>
            <div class="icon-box mt-5" data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-award"></i>
              <h4>Script Custom</h4>
              <p>In grado di fornirti la possibilità di ruolare in modo innovativo ed unico senza alcun limite!</p>
            </div>
            <div class="icon-box mt-5" data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-headphone"></i>
              <h4>Chat Vocale SaltyChat</h4>
              <p>Questo plugin da installare su TeamSpeak consente di avere una migliore esperienza acustica e immersiva all'interno del gioco</p>
            </div>
          </div>
          <div class="image col-lg-6 order-1 order-lg-2 " data-aos="zoom-in" data-aos-delay="100">
        <img src="assets/img/features.png" alt="" class="img-fluid"> 
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->


   <!--  <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Galleria</h2>
        </div>

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">Tutti</li>
              <li data-filter=".filter-app">Player</li>
              <li data-filter=".filter-card">Mappe</li>
              <li data-filter=".filter-web">Auto</li>
              <li data-filter=".filter-police">LSPD</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container">

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-1.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Toyota Supra</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/fotoauto/gtr.jpeg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Nissan GT-R</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/fotoauto/gtr.jpeg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-2.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Lamborghini Urus</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Delorean</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-4.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Dodo Idrovolante</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-5.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Villa Cayo Perico</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-5.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-6.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Jeep</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-6.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-7.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Autostrada</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-7.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-8.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Il Faro</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-8.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-9.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Parco Auto Medici</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-9.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-10.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Aurora Boreale</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-10.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-11.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Corte Marziale</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-11.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>
			
			<div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-12.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>CORVETTE ZR1</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-12.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>
			
			<div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/portfolio-13.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>AUDI RS6</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/portfolio-13.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-police">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/polizia-1.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Parco Auto LSPD</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/polizia-1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-police">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/polizia-2.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Parco Auto LSPD</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/polizia-2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-police">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/polizia-3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Parco Auto LSPD</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/polizia-3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-police">
            <div class="portfolio-wrap">
              <img src="https://upload.lemoncityrp.it/portfolio/polizia-4.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Parco Auto LSPD</h4>
              </div>
              <div class="portfolio-links">
                <a href="https://upload.lemoncityrp.it/portfolio/polizia-4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

        </div>

      </div> 
    </section>
 -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Domande Frequenti</h2>
          <p>Alcune delle domande che vengono poste spesso dai nostri giocatori!</p>
        </div>

        <div class="faq-list">
          <ul>

            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-1" class="collapsed">Come posso giocare nel server? 🕹️<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Per giocare su <strong>LemonCity</strong> avrai bisogno di una copia originale di <strong>Grand Theft Auto V</strong> installata sul tuo computer. <br>
                  Dopodichè ti basterà scaricare FiveM e connetterti al server comodamente tramite la lista
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">Cos'è il plugin SaltyChat? 🎧<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Questo <strong>plugin</strong> vi consentirà di parlare in gioco ottenendo un'esperienza auditiva migliore rispetto alla normale Chat Vocale di GTAV! <br>
                  Per scaricare e installare il <strong>SaltyChat</strong> potrai trovare una comoda <strong>guida sul nostro server Discord</strong> nel canale: #🎤│ꜱᴀʟᴛʏᴄʜᴀᴛ!
                </p>
              </div>
            </li>
			  
			  <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">Come posso collegarmi al Teamspeak? 🔊<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                <p>
                Ti basterà scaricare <strong>Teamspeak</strong> e connetterti al server TS incollando questo indirizzo: <strong>lemoncity.voicehosting.it</strong>
                </p>
              </div>
            </li>
			  
			  <li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">Come posso ricevere supporto?🙋‍♂️<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Entrando nel nostro <strong>discord.gg/lemoncityrp</strong> potrai recarti in<strong> #Attesa Assistenza</strong> in cui uno Staffer ti assisterà il prima possibile!
                </p>
              </div>
            </li>
			  
          </ul>
        </div>
		  

      </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contattaci</h2>
          <p>Siamo sempre disponibili per rispondere a qualsiasi quesito da parte di voi utenti. <br> Potete contattarci tramite:</p>
        </div>



        <div class="row">
          <div class="col-lg-6">
            <div class="info-box mb-4">
               <img src="https://upload.lemoncityrp.it/discord-icon.svg" width="32px" height="32px">
              <h3><a href="https://discord.gg/lemoncityrp" target="_blank">  Discord </a></h3>
              <p><a href="https://discord.gg/lemoncityrp" target="_blank">discord.gg/lemoncityrp</a></p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="info-box  mb-4">
              <img src="https://upload.lemoncityrp.it/Instagram.svg.png" width="32px" height="32px">
              <h3><a href="https://www.instagram.com/lemoncityrp_/" target="_blank"> Instagram </a> </h3>
              <p><a href="https://www.instagram.com/lemoncityrp_/" target="_blank">instagram.com/lemoncityrp_</a></p>
            </div>
          </div>
        </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="metti-giu">

    <div class="footer-top">
      <div class="container">
        <div class="row">


          <div class="col-lg-4 col-md-6 footer-links">
			  <h3><strong>LEMONCITY</strong></h3>
            <br>
            <p>Progetto creato e sviluppato da <strong>SteCk_</strong> & <strong>ShamZy.</strong><br>
            Si ringrazia l'intero corpo staff per la fiducia e l'impegno</p>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Link Utili</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://lemoncityrp.it/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://lemoncityrp.it/staff">Staff</a></li>
				<li><i class="bx bx-chevron-right"></i> <a href="changelog">ChangeLog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="tos">Terms of Service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="database">Database Vari</a></li>
            </ul>
          </div>



        </div>
      </div>
    </div>

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="me-md-auto text-center text-md-start">
          <div class="copyright">
            &copy; Copyright <strong><span>LemonCity</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            Developed by SteCk_ & ShamZy & Tommax.
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://discord.com/invite/lemoncityrp" target="_blank" class="twitter"><i class="fab fa-discord"></i></a>
          <a href="https://www.instagram.com/lemoncityrp_/" target="_blank" class="facebook"><i class="fab fa-instagram"></i></a>
          <a href="https://www.twitch.tv/lemoncity_rp" target="_blank" class="instagram"><i class="fab fa-twitch"></i></a>
          <a href="https://www.youtube.com/channel/UCzcYQU59Ub0rWRpJiH61GHQ" target="_blank" class="google-plus"><i class="fab fa-youtube"></i></a>
          <a href="https://www.tiktok.com/@lemoncityrp_" target="_blank" class="linkedin"><i class="fab fa-tiktok"></i></a>
        </div>
      </div>

    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <div id="preloader">
  <div id="loader"></div>
</div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="https://kit.fontawesome.com/2b98d1dd1f.js" crossorigin="anonymous"></script>        

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
	  
	    <!-- VANILLA TILT-->
  <script type="text/javascript" src="assets/js/vanilla-tilt.js"></script>

</body>

</html>

